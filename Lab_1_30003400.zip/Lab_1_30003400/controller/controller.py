from model.consultor import Consultor
from model.imovel import Imovel

def verify_pessoa(consultores, nif):
    for i in consultores:
        if i.get_nif() == nif:
            return True
    return False

def verify_imovel(imoveis, id):
    for i in imoveis:
        if i.get_id() == id:
            return True
    return False

def verify_imovel_consultor(consultores, nif, id):
    for i in consultores:
        if i.get_nif() == nif:
           return i.verify_imovel(id)

def register_consultor(nome, apelido, nif, consultores):
    consultor = Consultor(nome, apelido, nif)
    consultores.append(consultor)

def create_id(imoveis):
        id = len(imoveis) + 1
        return id

def register_imovel(imoveis, consultores, nif, localizacao, area, tipologia, ano, valor, comissao):
    id = create_id(imoveis)
    imovel = Imovel(nif, localizacao, area, tipologia, ano, valor, comissao, id)
    imoveis.append(imovel)
    for i in consultores:
        if i.get_nif() == nif:
            i.add_imovel(imovel)
    print("Imovel com", imovel.get_id() ,"registado com sucesso.")

def list_imoveis_consultor(nif, consultores):
    for i in consultores:
        if i.get_nif() == nif:
            if len(i.get_imoveis()) == 0:
                print("Nao existem imoveis registados.")
                return
            else:
                for y in i.get_imoveis():
                    print(y.get_id(), y.get_valor_venda_imovel(), y.get_comissao_venda_imovel(), sep=" ")
                return

def delete_imovel(consultores, nif, id):
    for i in consultores:
        if i.get_nif() == nif:
            i.remove_imovel(id)
            print("Imovel eliminado com sucesso") 

def delete_consultor(consultores, nif):
    lista_ids = []
    for i in consultores:
        if i.get_nif() == nif:
            for f in i.get_imoveis():
                lista_ids.append(f.get_id())
            consultores.remove(i)
            print("Consultor eliminado com sucesso.")
            print("Os imoveis",*lista_ids ,"tambem foram eliminados.")
            



