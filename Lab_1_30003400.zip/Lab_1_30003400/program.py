from view.cli import cli
import sys
sys.stdout.reconfigure(encoding="utf-8")

if __name__ == "__main__":
    cli()