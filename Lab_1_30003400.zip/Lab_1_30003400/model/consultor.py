from model.imovel import Imovel

class Consultor():
    def __init__(self, nome, apelido, nif) -> None:
        self.nome = nome
        self.apelido = apelido
        self.nif = nif
        self.lista_imoveis = []

    def get_nome(self):
        return self.nome

    def get_apelido(self):
        return self.apelido

    def get_nif(self):
        return self.nif
    
    def get_imoveis(self):
        return self.lista_imoveis
    
    def add_imovel(self, imovel):
        self.lista_imoveis.append(imovel)

    def verify_imovel(self, id):
        for i in self.lista_imoveis:
            if i.get_id() == id:
                return True
        return False
    
    def remove_imovel(self, id):
        for i in self.lista_imoveis:
            if i.get_id() == id:
                self.lista_imoveis.remove(i)


