class Imovel():
    def __init__(self, NIF_consultor, localizacao_imovel, area_util, tipologia_imovel, ano_imovel, valor_venda_imovel, comissao_venda_imovel, id) -> None:
        self.nif_consultor = NIF_consultor
        self.localizacao_imovel = localizacao_imovel
        self.area_util = area_util
        self.tipologia_imovel = tipologia_imovel
        self.ano_imovel = ano_imovel
        self.valor_venda_imovel = valor_venda_imovel
        self.comissao_venda_imovel = comissao_venda_imovel
        self.id = id
    

    def get_nif_consultor(self):
        return self.nif_consultor

    def get_localizacao_imovel(self):
        return self.localizacao_imovel

    def get_area_util(self):
        return self.area_util

    def get_tipologia_imovel(self):
        return self.tipologia_imovel

    def get_ano_imovel(self):
        return self.ano_imovel

    def get_valor_venda_imovel(self):
        return self.valor_venda_imovel

    def get_comissao_venda_imovel(self):
        return self.comissao_venda_imovel

    def get_id(self):
        return self.id