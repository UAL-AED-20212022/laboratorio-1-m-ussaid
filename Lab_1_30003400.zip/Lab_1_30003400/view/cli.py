import controller.controller as ctrler
from  controller.controller import *
def cli():
    imoveis = []
    consultores = []
    while True:
        comando = input()
        controlos = comando.split(" ")
        if  controlos[0]== "RC":
            if ctrler.verif_pessoa(consultores, controlos[3]):
                print("Não´e␣poss´ıvel␣realizar␣o␣registo,consultor␣j´a␣registado.")
            else:
                ctrler.registar_consultor(controlos[1], controlos[2], controlos[3], consultores)
                print("Consultor␣registado␣com␣sucesso.")
        elif controlos[0] == "RI":
            if len(controlos) < 8:
                print("Por␣favor␣verifique␣se␣todas␣as␣informa¸c~oes␣foram␣introduzidas.")
            elif ctrler.verif_pessoa(consultores, controlos[1]) is False:
                print("N~ao␣´e␣possivel␣realizar␣o␣registo␣do␣im´ovel,NIF␣inv´alido.")
            
            else:
                ctrler.registar_imovel(imoveis, consultores, controlos[1], controlos[2], controlos[3], controlos[4], controlos[5], controlos[6], controlos[7])

        elif controlos[0] == "LI":
            if ctrler.verif_pessoa(consultores, controlos[1]) is False:
                print("N~ao␣´e␣possivel␣realizar␣o␣registo␣do␣im´ovel,NIF␣inv´alido.")
            else:
                ctrler.listar_imoveis_consultor(controlos[1], consultores)

        elif controlos[0] == "EI":
            if ctrler.verif_imovel(imoveis, controlos[2]) is False:
                print("O␣ID␣indicado␣´e␣inv´alido")
            
            elif ctrler.verif_imovel_consultor(consultores, controlos[1], controlos[2]) is False:
                print("O␣im´ovel", controlos[2], "n~ao␣pertence␣ao␣consultor␣indicado.")
            
            else:
                ctrler.eliminar_imovel(consultores, controlos[1], controlos[2])
                print("vIm´ovel␣eliminado␣com␣sucesso.")

        elif controlos[0] == "EC":
            if ctrler.verif_pessoa(consultores, controlos[1]) is False:
                print("N~ao␣´e␣possivel␣realizar␣a␣opera¸c~ao,NIF␣inv´alido.")
            
            else:
                ctrler.eliminar_consultor(consultores, controlos[1])

        